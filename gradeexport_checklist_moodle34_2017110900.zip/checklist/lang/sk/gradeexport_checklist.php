<?php

$string['modulename'] = 'Kontrolný zoznam export';

$string['alldistrict'] = 'Všetko';

$string['choosechecklist'] = 'Kontrolný zoznam pre export';
$string['choosedistrict'] = 'Oblasť na zahrnutie';

$string['checklist:view'] = 'Zobraziť správu Kontrolného zoznamu (Excel)';
$string['checklist:viewall'] = 'Zobraziť správu Kontrolného zoznamu pre všetkých študentov kurzu';
$string['checklist:viewdistrict'] = 'Zobraziť správu Kontrolného zoznamu pre študentov v rovnakej oblasti';

$string['checklistnotfound'] = 'Kontrolný zoznam nebol nájdený';
$string['checklistreport'] = 'Správa';

$string['export'] = 'Export súboru do programu Excel';

$string['nochecklists'] = 'Žiadne vhodné zoznamy neboli nájdené';
$string['nodistrict'] = 'Chyba: súčasný užívateľ nemá žiadne oblast';
$string['nousers'] = 'Žiadny užívateľ na export';

$string['wrongdistrict'] = 'Nemáte oprávnenie na zobrazenie správy z tejto oblasti';

?>
