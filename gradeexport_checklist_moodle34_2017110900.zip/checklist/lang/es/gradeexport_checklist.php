<?php

$string['modulename'] = 'Exportaci&oacute;n Lista de Cotejo';

$string['alldistrict'] = 'Todo';

$string['choosechecklist'] = 'Lista de Cotejo para la exportaci&oacute;n';
$string['choosedistrict'] = 'Distrito para incluir';

$string['checklist:view'] = 'Ver informe de verificaci&oacute;n (Excel)';
$string['checklist:viewall'] = 'Ver informe Lista de cotejo para todos los estudiantes en el curso ';
$string['checklist:viewdistrict'] = 'Ver informe Lista de verificaci&oacute;n para los estudiantes de un mismo distrito';

$string['checklistnotfound'] = 'Lista de Cotejo no encontrada';
$string['checklistreport'] = 'Reporte';

$string['export'] = 'Exportar archivo Excel ';

$string['nochecklists'] = 'No hay listas de Cotejo adecuados';
$string['nodistrict'] = 'Error: usuario actual no tiene ning&uacute;n distrito';
$string['nousers'] = 'No hay los usuarios que exportar';

$string['wrongdistrict'] = 'Usted no tiene permiso para ver los informes de ese distrito';


